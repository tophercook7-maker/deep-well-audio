# Deep Well Audio Starter

A clean Next.js starter for **deepwellaudio.com**.

## What is included

- Branded homepage
- Explore directory page
- Show detail pages
- Member library teaser page
- Login placeholder page
- Seeded sample data for podcasts / sermons / Bible teaching
- Tailwind styling with a dark gold-accent brand look

## Good next moves

1. Deploy this starter to Vercel
2. Point `deepwellaudio.com` to the Vercel project
3. Replace seeded data in `lib/data.ts` with:
   - RSS ingestion
   - YouTube channel imports
   - Apple / Spotify / official links
4. Add Supabase for:
   - auth
   - profiles
   - favorites
   - playlists
5. Add filters:
   - topic
   - source
   - category
   - meaty score

## Suggested stack

- Next.js
- Tailwind CSS
- Vercel
- Supabase
- Podcast Index / RSS parser
- YouTube Data API

## Run locally

```bash
npm install
npm run dev
```

## Notes

This starter is intentionally lean. Launch the brand and the value prop first, then wire in live data and accounts.
