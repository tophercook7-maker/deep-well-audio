import Link from "next/link";
import type { Show } from "@/lib/data";
import { ArrowUpRight, Radio } from "lucide-react";

export function ShowCard({ show }: { show: Show }) {
  return (
    <article className="card p-5 transition hover:-translate-y-1 hover:border-accent/30">
      <div className="mb-4 flex items-start justify-between gap-4">
        <div>
          <span className="tag">{show.kind.replace("-", " ")}</span>
          <h3 className="mt-3 text-xl font-semibold">{show.title}</h3>
          <p className="mt-1 text-sm text-muted">{show.host}</p>
        </div>
        <Radio className="h-5 w-5 text-accent" />
      </div>

      <p className="text-sm leading-6 text-muted">{show.summary}</p>

      <div className="mt-4 flex flex-wrap gap-2">
        {show.tags.map((tag) => (
          <span key={tag} className="rounded-full border border-line px-3 py-1 text-xs text-slate-300">
            {tag}
          </span>
        ))}
      </div>

      <div className="mt-6 flex items-center justify-between">
        <span className="text-xs uppercase tracking-[0.25em] text-amber-100/70">
          {show.episodes.length} sample episodes
        </span>
        <Link
          href={`/shows/${show.slug}`}
          className="inline-flex items-center gap-2 text-sm font-medium text-amber-200 hover:text-white"
        >
          View show
          <ArrowUpRight className="h-4 w-4" />
        </Link>
      </div>
    </article>
  );
}
