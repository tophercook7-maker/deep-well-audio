import Link from "next/link";
import { Headphones, Library, Search, Heart } from "lucide-react";

const nav = [
  { href: "/explore", label: "Explore", icon: Search },
  { href: "/library", label: "Library", icon: Library },
  { href: "/#featured", label: "Featured", icon: Headphones },
];

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-50 border-b border-line/80 bg-bg/85 backdrop-blur">
      <div className="container-shell flex items-center justify-between py-4">
        <Link href="/" className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl border border-accent/30 bg-accent/10 text-accent">
            <Headphones className="h-5 w-5" />
          </div>
          <div>
            <p className="text-xs uppercase tracking-[0.3em] text-amber-200/80">Deep Well Audio</p>
            <p className="text-sm text-muted">Rich Bible teaching without the fluff</p>
          </div>
        </Link>

        <nav className="hidden items-center gap-2 md:flex">
          {nav.map(({ href, label, icon: Icon }) => (
            <Link
              key={href}
              href={href}
              className="flex items-center gap-2 rounded-full border border-line px-4 py-2 text-sm text-muted transition hover:border-accent/40 hover:text-text"
            >
              <Icon className="h-4 w-4" />
              {label}
            </Link>
          ))}
          <Link
            href="/login"
            className="ml-2 rounded-full bg-accent px-4 py-2 text-sm font-semibold text-slate-950 transition hover:opacity-90"
          >
            Member Login
          </Link>
        </nav>

        <Link
          href="/library"
          className="rounded-full border border-line p-2 text-muted md:hidden"
          aria-label="Library"
        >
          <Heart className="h-5 w-5" />
        </Link>
      </div>
    </header>
  );
}
