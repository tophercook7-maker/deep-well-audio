import { Play, ExternalLink } from "lucide-react";
import type { Episode } from "@/lib/data";

export function EpisodeRow({ episode }: { episode: Episode }) {
  return (
    <div className="card flex flex-col gap-4 p-4 md:flex-row md:items-center md:justify-between">
      <div className="flex items-start gap-4">
        <button
          className="mt-1 flex h-11 w-11 items-center justify-center rounded-full bg-accent text-slate-950"
          aria-label={`Play ${episode.title}`}
        >
          <Play className="h-5 w-5 fill-current" />
        </button>

        <div>
          <p className="text-xs uppercase tracking-[0.25em] text-amber-100/70">
            {episode.source} • {episode.duration} • {episode.publishedAt}
          </p>
          <h3 className="mt-1 text-lg font-semibold">{episode.title}</h3>
          <p className="mt-2 text-sm leading-6 text-muted">{episode.description}</p>

          <div className="mt-3 flex flex-wrap gap-2">
            {episode.topic.map((topic) => (
              <span key={topic} className="rounded-full border border-line px-3 py-1 text-xs text-slate-300">
                {topic}
              </span>
            ))}
            {episode.scripture?.map((verse) => (
              <span key={verse} className="rounded-full border border-accent/30 bg-accent/10 px-3 py-1 text-xs text-amber-200">
                {verse}
              </span>
            ))}
          </div>
        </div>
      </div>

      <a
        href="#"
        className="inline-flex items-center gap-2 self-start rounded-full border border-line px-4 py-2 text-sm text-muted hover:border-accent/40 hover:text-white"
      >
        Listen
        <ExternalLink className="h-4 w-4" />
      </a>
    </div>
  );
}
