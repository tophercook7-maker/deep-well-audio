export type Episode = {
  id: string;
  title: string;
  description: string;
  duration: string;
  publishedAt: string;
  source: "rss" | "youtube" | "apple";
  topic: string[];
  showSlug: string;
  scripture?: string[];
};

export type Show = {
  slug: string;
  title: string;
  host: string;
  summary: string;
  platform: string;
  kind: "sermons" | "bible-teaching" | "apologetics" | "church-history" | "spiritual-growth";
  artwork: string;
  tags: string[];
  featured: boolean;
  officialUrl: string;
  episodes: Episode[];
};

export const shows: Show[] = [
  {
    slug: "ask-pastor-john",
    title: "Ask Pastor John",
    host: "John Piper",
    summary: "Short, rich answers to serious Bible and theology questions.",
    platform: "RSS / Apple / Spotify",
    kind: "bible-teaching",
    artwork: "/placeholder-cover.svg",
    tags: ["Q&A", "Doctrine", "Meaty"],
    featured: true,
    officialUrl: "https://www.desiringgod.org/ask-pastor-john",
    episodes: [
      {
        id: "apj-1",
        title: "How do I keep reading my Bible when I feel dry?",
        description: "A sample episode entry for the starter build. Replace with live RSS data later.",
        duration: "12 min",
        publishedAt: "2026-03-20",
        source: "rss",
        topic: ["Bible Reading", "Discipline"],
        showSlug: "ask-pastor-john",
        scripture: ["Psalm 19", "John 6:68"]
      },
      {
        id: "apj-2",
        title: "What does real repentance look like?",
        description: "Starter content for layout, filtering, and show pages.",
        duration: "15 min",
        publishedAt: "2026-03-18",
        source: "apple",
        topic: ["Repentance", "Sanctification"],
        showSlug: "ask-pastor-john",
        scripture: ["2 Corinthians 7:10"]
      }
    ]
  },
  {
    slug: "bibleproject-podcast",
    title: "BibleProject Podcast",
    host: "BibleProject",
    summary: "Biblical theology, literary design, and long-form Bible conversations.",
    platform: "RSS / YouTube / Apple",
    kind: "bible-teaching",
    artwork: "/placeholder-cover.svg",
    tags: ["Biblical Theology", "Series", "Bible Books"],
    featured: true,
    officialUrl: "https://bibleproject.com/podcasts/shows/the-bible-project-podcast/",
    episodes: [
      {
        id: "bp-1",
        title: "The Book of Romans and the new family of God",
        description: "Sample episode for initial content seeding.",
        duration: "52 min",
        publishedAt: "2026-03-17",
        source: "rss",
        topic: ["Romans", "Paul", "Gospel"],
        showSlug: "bibleproject-podcast",
        scripture: ["Romans 1", "Romans 8"]
      }
    ]
  },
  {
    slug: "alisa-childers-podcast",
    title: "Alisa Childers Podcast",
    host: "Alisa Childers",
    summary: "Apologetics, discernment, worldview, and thoughtful discussions.",
    platform: "RSS / Apple / Spotify / YouTube",
    kind: "apologetics",
    artwork: "/placeholder-cover.svg",
    tags: ["Apologetics", "Discernment", "Debate"],
    featured: true,
    officialUrl: "https://alisachilders.com/podcast/",
    episodes: [
      {
        id: "ac-1",
        title: "Why doctrine still matters in an emotional age",
        description: "Sample apologetics content block for MVP.",
        duration: "61 min",
        publishedAt: "2026-03-16",
        source: "youtube",
        topic: ["Doctrine", "Discernment"],
        showSlug: "alisa-childers-podcast",
        scripture: ["2 Timothy 4:3"]
      }
    ]
  },
  {
    slug: "renewing-your-mind",
    title: "Renewing Your Mind",
    host: "Ligonier Ministries",
    summary: "Classic theological teaching for serious discipleship.",
    platform: "RSS / Apple / Spotify",
    kind: "bible-teaching",
    artwork: "/placeholder-cover.svg",
    tags: ["Theology", "Teaching", "Foundations"],
    featured: false,
    officialUrl: "https://learn.ligonier.org/podcasts/renewing-your-mind",
    episodes: [
      {
        id: "rym-1",
        title: "The holiness of God and the fear of the Lord",
        description: "Starter entry for browsing and category pages.",
        duration: "28 min",
        publishedAt: "2026-03-15",
        source: "rss",
        topic: ["Holiness", "Fear of the Lord"],
        showSlug: "renewing-your-mind",
        scripture: ["Isaiah 6"]
      }
    ]
  }
];

export const allEpisodes = shows.flatMap((show) => show.episodes).sort((a, b) =>
  new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime()
);

export const categories = [
  { key: "sermons", label: "Sermons" },
  { key: "bible-teaching", label: "Bible Teaching" },
  { key: "apologetics", label: "Apologetics / Debate" },
  { key: "church-history", label: "Church History" },
  { key: "spiritual-growth", label: "Spiritual Growth" }
] as const;
