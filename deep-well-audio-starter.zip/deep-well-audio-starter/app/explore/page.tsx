import { categories, shows } from "@/lib/data";
import { ShowCard } from "@/components/show-card";

export default function ExplorePage() {
  return (
    <main className="container-shell py-14">
      <div className="mb-10">
        <span className="tag">Explore</span>
        <h1 className="mt-4 text-4xl font-semibold">Browse the Deep Well directory</h1>
        <p className="mt-4 max-w-2xl text-muted">
          This starter build uses seeded content so you can launch the brand first and wire up RSS, YouTube, and member accounts next.
        </p>
      </div>

      <div className="mb-8 flex flex-wrap gap-3">
        {categories.map((category) => (
          <span key={category.key} className="rounded-full border border-line px-4 py-2 text-sm text-slate-300">
            {category.label}
          </span>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-2 xl:grid-cols-3">
        {shows.map((show) => (
          <ShowCard key={show.slug} show={show} />
        ))}
      </div>
    </main>
  );
}
