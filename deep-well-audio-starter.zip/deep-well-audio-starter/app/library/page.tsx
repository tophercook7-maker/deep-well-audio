import { Heart, LockKeyhole, ListMusic, NotebookPen, UserRound } from "lucide-react";

export default function LibraryPage() {
  const features = [
    {
      icon: Heart,
      title: "Favorites",
      text: "Save shows and episodes for quick return visits."
    },
    {
      icon: ListMusic,
      title: "Playlists",
      text: "Build topic-based collections like Romans, prophecy, and apologetics."
    },
    {
      icon: NotebookPen,
      title: "Notes",
      text: "Add member notes and scripture reflections later."
    },
    {
      icon: UserRound,
      title: "Profiles",
      text: "Each member gets a personal listening home."
    }
  ];

  return (
    <main className="container-shell py-14">
      <div className="card overflow-hidden">
        <div className="grid gap-8 p-8 lg:grid-cols-[1fr_0.8fr] lg:items-center">
          <div>
            <span className="tag">Member area</span>
            <h1 className="mt-4 text-4xl font-semibold">Your saved library lives here</h1>
            <p className="mt-4 max-w-2xl leading-7 text-muted">
              In the MVP, this page explains the value of accounts before full auth is wired in. Next step:
              connect Supabase auth, create a favorites table, and show real saved items.
            </p>
          </div>

          <div className="rounded-3xl border border-accent/25 bg-accent/10 p-6">
            <div className="flex items-center gap-3 text-amber-200">
              <LockKeyhole className="h-5 w-5" />
              <p className="font-medium">Ready for login later</p>
            </div>
            <p className="mt-3 text-sm leading-6 text-slate-200">
              Start with email magic links or Google auth. Keep it lightweight and only add premium gating after people actually use the site.
            </p>
          </div>
        </div>
      </div>

      <div className="mt-8 grid gap-6 md:grid-cols-2">
        {features.map(({ icon: Icon, title, text }) => (
          <div key={title} className="card p-6">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-accent/30 bg-accent/10 text-accent">
              <Icon className="h-5 w-5" />
            </div>
            <h2 className="mt-4 text-xl font-semibold">{title}</h2>
            <p className="mt-3 text-sm leading-6 text-muted">{text}</p>
          </div>
        ))}
      </div>
    </main>
  );
}
