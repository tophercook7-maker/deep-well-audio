import Link from "next/link";
import { categories, allEpisodes, shows } from "@/lib/data";
import { ShowCard } from "@/components/show-card";
import { EpisodeRow } from "@/components/episode-row";
import { ArrowRight, BookOpen, Headphones, Mic2, ShieldCheck, Star } from "lucide-react";

const featured = shows.filter((show) => show.featured);

export default function HomePage() {
  return (
    <main>
      <section className="container-shell py-16 sm:py-20">
        <div className="grid gap-10 lg:grid-cols-[1.2fr_0.8fr] lg:items-center">
          <div>
            <span className="tag">Now building the first curated Christian audio hub</span>
            <h1 className="mt-6 max-w-4xl text-4xl font-semibold leading-tight sm:text-5xl lg:text-6xl">
              Find <span className="text-amber-200">rich Bible teaching</span> without digging through fluff.
            </h1>
            <p className="mt-6 max-w-2xl text-lg leading-8 text-muted">
              Deep Well Audio brings sermons, Bible teaching podcasts, apologetics, and selected YouTube teaching
              into one clean, searchable place. Start free, save favorites, and grow into curated members-only tools later.
            </p>

            <div className="mt-8 flex flex-wrap gap-4">
              <Link
                href="/explore"
                className="inline-flex items-center gap-2 rounded-full bg-accent px-6 py-3 text-sm font-semibold text-slate-950"
              >
                Explore audio
                <ArrowRight className="h-4 w-4" />
              </Link>
              <Link
                href="/library"
                className="inline-flex items-center gap-2 rounded-full border border-line px-6 py-3 text-sm font-semibold text-white"
              >
                See member library
              </Link>
            </div>

            <div className="mt-10 grid gap-4 sm:grid-cols-3">
              {[
                { label: "Curated Sources", value: "Official feeds only" },
                { label: "MVP Model", value: "Free site first" },
                { label: "Monetization", value: "Memberships later" },
              ].map((item) => (
                <div key={item.label} className="card p-4">
                  <p className="text-xs uppercase tracking-[0.25em] text-amber-100/70">{item.label}</p>
                  <p className="mt-2 font-medium">{item.value}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="card p-6">
            <p className="text-xs uppercase tracking-[0.3em] text-amber-100/70">Launch categories</p>
            <div className="mt-5 grid gap-4">
              {categories.map((category) => (
                <div key={category.key} className="flex items-center justify-between rounded-2xl border border-line bg-soft/40 p-4">
                  <div className="flex items-center gap-3">
                    <div className="rounded-2xl border border-accent/25 bg-accent/10 p-2 text-accent">
                      {category.key === "sermons" ? <Mic2 className="h-5 w-5" /> :
                       category.key === "bible-teaching" ? <BookOpen className="h-5 w-5" /> :
                       category.key === "apologetics" ? <ShieldCheck className="h-5 w-5" /> :
                       <Headphones className="h-5 w-5" />}
                    </div>
                    <div>
                      <p className="font-medium">{category.label}</p>
                      <p className="text-sm text-muted">Curated and tagged</p>
                    </div>
                  </div>
                  <Star className="h-4 w-4 text-amber-200" />
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section id="featured" className="container-shell py-10">
        <div className="mb-8 flex items-end justify-between gap-6">
          <div>
            <p className="text-xs uppercase tracking-[0.3em] text-amber-100/70">Featured shows</p>
            <h2 className="mt-2 text-3xl font-semibold">Seed the site with strong sources</h2>
          </div>
          <Link href="/explore" className="text-sm text-amber-200 hover:text-white">
            View all shows
          </Link>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          {featured.map((show) => (
            <ShowCard key={show.slug} show={show} />
          ))}
        </div>
      </section>

      <section className="container-shell py-14">
        <div className="mb-8">
          <p className="text-xs uppercase tracking-[0.3em] text-amber-100/70">Latest sample episodes</p>
          <h2 className="mt-2 text-3xl font-semibold">Starter player layout</h2>
        </div>

        <div className="space-y-4">
          {allEpisodes.slice(0, 4).map((episode) => (
            <EpisodeRow key={episode.id} episode={episode} />
          ))}
        </div>
      </section>

      <section className="container-shell py-10 pb-20">
        <div className="card grid gap-8 p-8 lg:grid-cols-2 lg:items-center">
          <div>
            <p className="text-xs uppercase tracking-[0.3em] text-amber-100/70">Monetization path</p>
            <h2 className="mt-2 text-3xl font-semibold">Free now. Valuable later.</h2>
            <p className="mt-4 max-w-2xl leading-7 text-muted">
              Start by letting people browse and save favorites. Later, unlock playlists, notes, advanced filters,
              scripture-linked listening, curated collections, and ad-free member tools.
            </p>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            {[
              "Free discovery and listening",
              "User accounts and favorites",
              "Premium playlists and notes",
              "Curated weekly email digest",
            ].map((item) => (
              <div key={item} className="rounded-2xl border border-line bg-soft/30 p-4 text-sm text-slate-200">
                {item}
              </div>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}
