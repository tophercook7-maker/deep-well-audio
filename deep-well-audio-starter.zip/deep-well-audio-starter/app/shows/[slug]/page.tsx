import { notFound } from "next/navigation";
import Link from "next/link";
import { shows } from "@/lib/data";
import { EpisodeRow } from "@/components/episode-row";
import { ArrowLeft, ExternalLink } from "lucide-react";

export default async function ShowDetailPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const show = shows.find((item) => item.slug === slug);

  if (!show) {
    notFound();
  }

  return (
    <main className="container-shell py-14">
      <Link href="/explore" className="inline-flex items-center gap-2 text-sm text-amber-200 hover:text-white">
        <ArrowLeft className="h-4 w-4" />
        Back to explore
      </Link>

      <section className="mt-6 card p-8">
        <div className="grid gap-6 lg:grid-cols-[1fr_auto] lg:items-start">
          <div>
            <span className="tag">{show.kind.replace("-", " ")}</span>
            <h1 className="mt-4 text-4xl font-semibold">{show.title}</h1>
            <p className="mt-3 text-lg text-slate-300">{show.host}</p>
            <p className="mt-5 max-w-3xl leading-7 text-muted">{show.summary}</p>

            <div className="mt-5 flex flex-wrap gap-2">
              {show.tags.map((tag) => (
                <span key={tag} className="rounded-full border border-line px-3 py-1 text-xs text-slate-300">
                  {tag}
                </span>
              ))}
            </div>
          </div>

          <a
            href={show.officialUrl}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 rounded-full border border-line px-5 py-3 text-sm text-muted hover:border-accent/40 hover:text-white"
          >
            Official source
            <ExternalLink className="h-4 w-4" />
          </a>
        </div>
      </section>

      <section className="mt-10">
        <div className="mb-5">
          <p className="text-xs uppercase tracking-[0.3em] text-amber-100/70">Episodes</p>
          <h2 className="mt-2 text-2xl font-semibold">Starter entries for this show</h2>
        </div>
        <div className="space-y-4">
          {show.episodes.map((episode) => (
            <EpisodeRow key={episode.id} episode={episode} />
          ))}
        </div>
      </section>
    </main>
  );
}
