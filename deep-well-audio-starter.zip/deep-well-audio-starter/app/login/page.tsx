export default function LoginPage() {
  return (
    <main className="container-shell py-16">
      <div className="mx-auto max-w-xl card p-8">
        <span className="tag">Coming next</span>
        <h1 className="mt-4 text-3xl font-semibold">Member login</h1>
        <p className="mt-4 leading-7 text-muted">
          Wire this page to Supabase Auth when you're ready. Recommended MVP:
          email magic links first, social login later.
        </p>

        <div className="mt-8 grid gap-4">
          <input
            disabled
            placeholder="Email address"
            className="rounded-2xl border border-line bg-soft/50 px-4 py-3 text-sm text-slate-300 outline-none"
          />
          <button
            disabled
            className="rounded-2xl bg-accent px-4 py-3 text-sm font-semibold text-slate-950 opacity-80"
          >
            Send magic link
          </button>
        </div>
      </div>
    </main>
  );
}
